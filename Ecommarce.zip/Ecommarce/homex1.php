<!DOCTYPE html>
<html>
<head>
<title>Man</title>
</head>
<body>

<h1 align="center">Welcome_Viewers</h1></br>


<p align= "center" ><a href="page1.html"><b>Shirt</b></a>&nbsp&nbsp&nbsp&nbsp&nbsp <a href=""><b>Pant</b></a>&nbsp&nbsp&nbsp&nbsp&nbsp<a href=""><b>Blazer</b></a>&nbsp&nbsp&nbsp&nbsp&nbsp<a href=""><b>Suit</b></a></p> 
 
 products:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp 
				
				

<select name="forma" onchange="location = this.value">
 <option value="">Select</option>
 <option value="www.google.com">Contact</option>
 <option value="signup.php">Sitemap</option>
</select>




</br></br></br></b><h2> sss </h2>
</br></br></br>

<footer>
  <p align="center">Posted by: Hege Refsnes</p>
  <p align="center">Contact information: <a href="mailto:someone@example.com">someone@example.com</a>.</p>
</footer>

</body>
</html>