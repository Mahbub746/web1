<?php

mysql_connect("localhost","root","");
mysql_select_db("data1");

$q= mysql_query("select * from re1");
$rowc= mysql_num_rows($q);
?>


<table >

<?php

for($i=1; $i<=$rowc; $i++)
{
	$r =mysql_fetch_array($q);
	
	



?>

<tr>
  <td><a href="re1/<?php echo $r["file"] ?>"><?php echo $r["file"] ?></a></td>
</tr>

<?php

}


?>



</table>