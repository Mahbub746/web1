<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>
	<p1>LOGIN</p1>
</head>
<body>

		<fieldset>
			

			<form method="post" action="logc.php">
				
				User Name: <input type="text" name="user" placeholder="text"> <br/>
				Password : &nbsp&nbsp<input type="password" name="pass" value="pass"><br/><br/>
				
				<tr>
				
				
				
				
						   &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp<input type="submit" name="Login" value="Signin">&nbsp&nbsp &nbsp&nbsp
						   <input type="submit" name="Forgetpass" value="Forget password">
						   
			</form>
		</fieldset>
</body>
</html>