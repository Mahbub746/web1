<?php

mysql_connect("localhost","root","");
mysql_select_db("data1");
if(isset($_POST['submit']))
 {
	 //$f_name = $_POST ['f_name'] ;
	 $file = $_FILES['myfile']['name'];
	 
	 
	 $tmp_loc = $_FILES['myfile']['tmp_name'];
	 $file_store = "re1/".$file ;
	 $file1= explode(".", $file);
	 $ext= $file1[1];
	 $all= array( "pdf" , "png" , "jpg" );
	 
	if(in_array($ext ,$all ))
	{
		move_uploaded_file($tmp_loc, $file_store);
		mysql_query("insert into re1(file)values('$file')");
		header('location: download.php');
	}
		
	
	 
 }

?>


<html>
<body>
<form enctype = "multipart/form-data" action="up.php"  method="post" >

   File upload:&nbsp&nbsp <input type="file" name="myfile"  placeholder="Browse" ><br/><br/>
				&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <input type="submit" name="submit" value="upload"><br/><br/>


				</form>
</body>
</html>