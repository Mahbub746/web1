<?php
mysql_connect("localhost","root","");
mysql_select_db("data1");

if(isset($_POST['submit']))
 {
	 $f_name = $_POST ['f_name'] ;
	 $name = $_FILES['myfile']['name'];
	 //$file_type = $_FILES['file']['type'];
	 //$file_size = $_FILES['file']['size'];
	 $tmp_name = $_FILES['myfile']['tmp_name'];
	 //$file_store = "upload/".$file_name ;
	 
	//move_uploaded_file($file_tem_loc, $file_store)
	if($name && $f_name)
	{
		$location = "re1/$name" ;
		move_uploaded_file($tmp_name, $location);
		$query = mysql_query("Insert into re1 (name,path) values ( $f_name, $location)");
		header(' location: d1.php ');
		
		
	}
	else
		
	echo "upload f";
	 
 }

?>


<html>
<body>
<form action="upload.php" method="post" enctype = "multipart/form-data">
&nbsp&nbsp <input type="text" name="f_name" ><br/><br/>
Upload image:&nbsp&nbsp <input type="file" name="myfile" ><br/><br/>
				&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <input type="submit" name="submit" value="upload"><br/><br/>


				</form>
</body>
</html>