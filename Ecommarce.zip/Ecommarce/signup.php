<html>
<head>
	<title>SIGNUP</title>
	<p1>SIGNUP</p1>
</head>
<body>

		<fieldset>
			

			<form action="regc.php" method="post" enctype="multipart/from-data">
				
				User Name: <input type="text" name="user" value="text"> <br/>
				Password : &nbsp<input type="password" name="pass" value="pass"><br/><br/>
				
				
				Gender:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <Select name="gender" />
				<option value="">Select</option>
				<option value="Male">Male</option>
				<option value="Female">Female</option>
				<option value="Others">Others</option>
				
				

				</Select><br/><br/>
				Upload image:&nbsp&nbsp <input type="file" name="file" ><br/><br/>
				&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <input type="submit" name="upload" value="upload Image"><br/><br/>
				
				
				
				Email: &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="email" name="email" ><br/><br/>
				
						   <input type="submit" name="Signup" value="Signup"><br/>
						   
			</form>
		</fieldset>
</body>
</html>