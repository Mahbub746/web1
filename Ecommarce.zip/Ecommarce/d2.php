<?php
$error = "error";

$host= "localhost";
	 $dbUsername="root";
	 $dbPassword="";
	 $dbname= "data1";
 
  
  $conn = mysqli_connect($host, $dbUsername, $dbPassword) or die($error) ;
  
    mysqli_select_db( $conn , $dbname) or die($error) ;

?>